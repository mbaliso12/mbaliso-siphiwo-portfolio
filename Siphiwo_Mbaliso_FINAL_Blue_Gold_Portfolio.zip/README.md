# Siphiwo Mbaliso — Final Portfolio

GitHub Pages-ready portfolio with:
- blue + gold premium AI design
- animated moving technology ticker and shimmer headline
- changeable profile photo
- professional CV
- all six verified Google/Coursera certificate PDFs
- certificate cards with direct View Certificate buttons
- skills, education, project, contact, GitHub and LinkedIn
- browser file preview area

Upload the entire repository structure to GitHub and enable Pages from `main` / root.

For a public photo change, replace `assets/siphiwo.jpg` while keeping the filename.
